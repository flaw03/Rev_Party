for i in range(100):
    if (i < 20):
        print(i,",06/09/2023 09:58:31,Test projet,shah,5,4,1,2,3")
    elif (i < 38):
        print(i,",06/09/2023 09:58:31,Test projet,shah,1,5,2,3,4")
    elif (i < 54):
        print(i,",06/09/2023 09:58:31,Test projet,shah,5,4,3,1,2")
    elif (i < 67):
        print(i,",06/09/2023 09:58:31,Test projet,shah,5,1,3,4,2")
    elif (i < 79):
        print(i,",06/09/2023 09:58:31,Test projet,shah,1,5,3,4,2")
    elif (i < 90):
        print(i,",06/09/2023 09:58:31,Test projet,shah,5,2,4,3,1")
    else:
        print(i,",06/09/2023 09:58:31,Test projet,shah,1,5,4,2,3")


